1. Rename the example.env file to .env
2. Open the .env file and paste your bot's token
3. install required packages:

<--- Required Packages --->

discord-player@5.1.0
ffmpeg-static@5.0.0
ms@2.1.3
fs
node-fetch@3.2.3
node-fetch2@1.6.3
@discordjs/opus@0.7.0
youtube-search@1.1.6
yt-search@2.10.3
ytdl-core@4.11.2
@discordjs/rest
discord-api-types

<--- Required Packages End --->

4. Go to the functions folder => then handleCommands.js and fill the required information! (CLIENT_ID)
5. run the bot and enjoy
Notes: after your first attemp on runnning the bot, go to functions folder => handleCommands.js and make the highlighted section a comment